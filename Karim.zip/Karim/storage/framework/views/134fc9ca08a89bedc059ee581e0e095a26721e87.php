<ul>
<li><a href="/about"> About</a> </li>
<li><a href="/list"> List</a></li>
<li><a href="/master"> Master</a></li>
<li><a href="/nav"> Navigation</a></li>
</ul>

<br>

<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
    }

    th{
        background-color: #dddddd;
    }

    td, th {
    border: 1px solid #dddddd;
    text-align: left;
    border: 1px solid #ddd;
    padding: 8px;
    }
</style>

<div class="container">
    <div class="row">
        <div class="col-md12">
        <table>
<tr>
<th>Title</th>
<th>Author</th>
<th>ISBN</th>
<th>Category</th>
<th>Page Count</th>
</tr>

<tr>
<td>The Push: A Novel</td>
<td>ASHLEY AUDRAIN</td>
<td>8053590881250</td>
<td>Thriller</td>
<td>425</td>
</tr>

<tr>
<td>A Crooked Tree</td>
<td>UNA MANNION</td>
<td>5788129116382</td>
<td>Novel</td>
<td>369</td>
</tr>

<tr>
<td>The Wife Upstairs</td>
<td>RACHEL HAWKINS</td>
<td>5478911612397</td>
<td>Novel</td>
<td>356</td>
</tr>

<tr>
<td>Summerwater</td>
<td>SARAH MOSS</td>
<td>5689632306567</td>
<td>History</td>
<td>286</td>
</tr>
<tr>

<td>Life Among the Terranauts</td>
<td>CAITLIN HORROCKS</td>
<td>9632306567257</td>
<td>Romantic</td>
<td>498</td>
</tr>

</table>
        </div>
    </div>
</div><?php /**PATH C:\Users\ADMIN\Downloads\Karim\resources\views/subview/list.blade.php ENDPATH**/ ?>