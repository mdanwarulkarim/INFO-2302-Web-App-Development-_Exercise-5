<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
    }

    th{
        background-color: #dddddd;
    }

    td, th {
    border: 1px solid #dddddd;
    text-align: left;
    border: 1px solid #ddd;
    padding: 8px;
    }
</style>

<div class="container">
    <div class="row">
        <div class="col-md12">
        <table>
<tr>
<th>Title</th>
<th>Author</th>
<th>ISBN</th>
<th>Category</th>
<th>Page Count</th>
</tr>

<tr>
<td>Grant</td>
<td>Chernow Ron</td>
<td>1080535908811</td>
<td>History</td>
<td>253</td>
</tr>

<tr>
<td>Genghis Khan and the Making of the Modern World</td>
<td>George Orwell</td>
<td>9788129116123</td>
<td>History</td>
<td>312</td>
</tr>

<tr>
<td>LOLITA</td>
<td>Vladimir Nabokov</td>
<td>1254789116123</td>
<td>Novel</td>
<td>251</td>
</tr>

<tr>
<td>CATCH-22</td>
<td>Aldous Huxley</td>
<td>5896323065671</td>
<td>Novel</td>
<td>304</td>
</tr>

</table>
        </div>
    </div>
</div><?php /**PATH C:\Users\User\Prince\resources\views/subview/list.blade.php ENDPATH**/ ?>